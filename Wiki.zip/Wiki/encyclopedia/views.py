import re

import random

from django import forms

from django.urls import reverse

from django.shortcuts import render

from django.http import HttpResponse, HttpResponseRedirect

from markdown2 import markdown

from . import util

# Form query searching
class QueryForm(forms.Form):

    query = forms.CharField( label=False, widget=forms.TextInput(
        attrs={"class":"search", "type":"text","placeholder":"Search Encyclopedia", "name":"q"}))
    
# Form for creating entry
class CreateForm(forms.Form):

    title = forms.CharField(label="Title", 
                            widget=forms.TextInput(attrs={"type":"text", "class":"create", "name":"title"}))

    content = forms.CharField(label=False, 
                              widget=forms.Textarea(attrs={"name":"content", "style": "height: 5rem;" "width: 40rem;", "placeholder":"Write your markdown content here"}))
    
# Form for editing entry    
class EditForm(forms.Form):
    content = forms.CharField(label=False, 
                              widget=forms.Textarea(attrs={"name":"content", "style": "height: 5rem;" "width: 40rem;", "placeholder":"Write your content here"}))


def index(request):
    """
    Render query search form on left sidebar.
    Render list of entries on home page.
    Enabling each list item to redirect to their entry page upon clciking.
    Making Random page lick on sidebar functional.
    
    """

    cleanform = ""
    entries = util.list_entries()
    if request.method == "POST":

        form = QueryForm(request.POST)

        if form.is_valid():
            cleanform = form.cleaned_data["query"]

        for entri in entries:

            if entri is not None and cleanform.lower() == entri.lower():

                return HttpResponseRedirect(reverse("wiki:entry", args=[entri]))
            
        pattern = re.compile(f".*{cleanform}.*", re.IGNORECASE)

        match_list = [entri for entri in entries if pattern.match(entri.lower())]
            
        return render(request, "encyclopedia/search.html", {
            "entries": match_list,
            "form": QueryForm(),
            "name": None
            })
    else:

        name = random.choice(entries)

        return render(request, "encyclopedia/index.html", {
            "entries": entries,
            "form": QueryForm(),
            "name": name

            })


def entry(request, name):

    """
    Render entry name/title, content and again sidebar query form.
    Using markdown2 library to convert markdown to HTML.
    Render HttpResopnse when entry not found.
    
    """
    entry = util.get_entry(name)
    
    if entry != None:
        return render(request, "encyclopedia/entry.html", {
            "name":  name,
            "content": markdown(entry),
            "form": QueryForm()
        })
    
    else:
        return HttpResponse("<h1>Not Found 404</h1>")
    

def newpage(request, name=None):

    """
    Render same sidebar on create page.
    If method is POST render create form.
    Check title and content of entry and save them.
    Then redirect to newly created  entry page. 

    """


    if request.method == "GET":
        if name is None:
            entries = util.list_entries()
            name = random.choice(entries)

        return render(request, "encyclopedia/new.html", {
            "form": QueryForm(),
            "createform": CreateForm(),
            "name": name
        })
    
    else:
        form = CreateForm(request.POST)

        if form.is_valid():
            title = form.cleaned_data["title"]
            content = form.cleaned_data["content"]

            entry = util.get_entry(title)

            if entry != None:
                return HttpResponse("<h1>Title Already Exists</h1>")
            
            util.save_entry(title, content)

            return HttpResponseRedirect(reverse("wiki:entry", args=[title]))
        
        else:
            return render(request, "encyclopedia/new.html", {
                "form": QueryForm(),
                "createform": form
            })
        
    
def editpage(request, name):

    """
    If method is GET, render edit template with Edit form pre populated with existing markdown content.
    Else recieve post data(any changes in content), change entry content and redirect to modified entry page. 
    
    """
    if request.method == "GET":

        entry = util.get_entry(name)

        entry_dict = {"content": entry}

        form = EditForm(initial=entry_dict)

        return render(request, "encyclopedia/edit.html", {
            "form": QueryForm(),
            "createform": form,
            "name": name
            })

    else:
        form = EditForm(request.POST)

        if form.is_valid():
            content = form.cleaned_data["content"]

            util.save_entry(name, content)

            return HttpResponseRedirect(reverse("wiki:entry", args=[name]))
        
        else:
            return render(request, "encyclopedia/edit.html", {
            "form": QueryForm(),
            "createform": form,
            "name": name
            })
         
