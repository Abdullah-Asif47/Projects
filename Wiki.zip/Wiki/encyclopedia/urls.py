from django.urls import path

from . import views

app_name = "wiki"

urlpatterns = [
    path("", views.index, name="index"),
    path("<str:name>", views.entry, name="entry"),
    path("newpage/", views.newpage, name="new_page"),
    path("editpage/<str:name>", views.editpage, name="edit_page")
    ]
